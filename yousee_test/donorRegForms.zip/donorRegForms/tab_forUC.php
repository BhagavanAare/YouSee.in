<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>


<table border="0">
  <tr>
    <td>
      <label>Feature Permission <span class="link"><a href="javascript: void(0)"><font face=verdana,arial,helvetica size=2>[?]</font><span>For featuring your photo and Quote on YouSee website. We request you to select "YES"</span></a></span></label>
    </td>
    <td>    <label><input type="radio" name="featurePermission" value="Y" id="FeaturePermission_y" />
        yes</label>

      <label>
        <input type="radio" checked name="featurePermission" value="N" id="FeaturePermission_n" />
        no </label>
      
    </td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td style="vertical-align:top;"><label for="quote">Quote <span class="link"><a href="javascript: void(0)"><font face=verdana,arial,helvetica size=2>[?]</font><span>Please show a brief (1-3 lines) quote about your thoughts on volunteer,donations and overall about UC (max 300 characters)</span></a></span></label></td>
    <td><span style="vertical-align:top;">
      <textarea placeholder="Please show a brief (1-3 lines) quote about your thoughts on volunteer,donations and overall about UC" name="featureQuote" id="quote" cols="45" rows="5"></textarea>
    </span></td>
    <td>&nbsp;</td>
  </tr>

</table>


</body>
</html>