<?php
$projects;

$project['id']="project_id";
$project['title']="project_title";
$project['desc']="project_description";
$project['location']="location";
$project['latitude']="latitude";
$project['longitude']="longitude";
$project['area']="project_area";
$project['status']="project_status";
?>