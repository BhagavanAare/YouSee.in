
<?php
$user['id']="user_id";
$user['typeID']="user_type_id";
$user['username']="username";
$user['password']="password";
$user['regStatus']="registration_status";

$userInsertAtts="".$user['typeID'].",".$user['username'].",".$user['password'].",".$user['regStatus'];


?>