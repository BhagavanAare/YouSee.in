<?php
$donor['id']="donor_id";
$donor['type']="type_of_donor";
$donor['fname']="first_name";
$donor['lname']="last_name";
$donor['dob']="dob";
$donor['gender']="gender";
$donor['address']="address";
$donor['city']="village_town";
$donor['state']="state";
$donor['country']="country";
$donor['pincode']="pin_code";
$donor['occupation']="occupation";
$donor['designation']="title_designation";
$donor['phno']="mobile_phone_no";
$donor['alternateEmail']="alternate_email";
$donor['preferredEmail']="preferred_email";

$donor['pan']="pan";
$donor['featurePermission']="feature_permission";
$donor['featureQuote']="feature_quote";
$donor['displayName']="displayname";
$donor['img']="donor_img";
$donor['orgName']="org_grp_name";
$donor['orgType']="org_grp_type";
$donor['orgDesc']="org_grp_description";
$donor['userID']="user_id";

$donorInsertAtts="".$donor['type'].",".$donor['fname'].",".$donor['lname'].",".$donor['dob'].",".$donor['gender'].",".$donor['address'].",".$donor['city'].",".$donor['state'].",".$donor['country'].",".$donor['pincode'].",".$donor['occupation'].",".$donor['designation'].",".$donor['phno'].",".$donor['alternateEmail'].",".$donor['preferredEmail'].",".$donor['pan'].",".$donor['featurePermission'].",".$donor['featureQuote'].",".$donor['displayName'].",".$donor['img'].",".$donor['orgName'].",".$donor['orgType'].",".$donor['orgDesc'].",".$donor['userID']."";

		

?>