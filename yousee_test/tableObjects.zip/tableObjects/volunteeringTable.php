<?php

$volunteer;

$volunteer['id']="volunteer_act_id";
$volunteer['donorId']="donor_id";
$volunteer['fromDate']="from_date";
$volunteer['toDate']="to_date";
$volunteer['fromTime']="from_time";
$volunteer['toTime']="to_time";
$volunteer['hours']="hours";
$volunteer['donationType']="donation_type";
$volunteer['area']="area";
$volunteer['activity']="activity_done";
$volunteer['onOff']="onsite_offsite";
$volunteer['location']="location";
$volunteer['org']="organisation";
$volunteer['notes']="notes";
$volunteer['projectId']="project_id";
$volunteer['status']="approval_status";
?>