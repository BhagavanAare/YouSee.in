<?php

	$ngo['id']="partner_id";
	$ngo['name']="name";
	$ngo['type']="type";
	$ngo['address']="address";
	$ngo['city']="hq_town_city";
	$ngo['state']="hq_state";
	$ngo['country']="hq_country";
	$ngo['pincode']="hq_pin_code";
	$ngo['fname']="contact_first_name";
	$ngo['lname']="contact_last_name";
	$ngo['gender']="contact_person_gender";
	$ngo['designation']="contact_person_designation";
	$ngo['phone']="contact_person_phone";
	$ngo['contactEmail']="contact_person_email";
	$ngo['url']="website_url";
	$ngo['logopath']="logo_path";
	$ngo['userid']="user_id";
	$ngo['partnerEmail']="partner_email";

?>