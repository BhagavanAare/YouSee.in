<?php
include('prod_conn.php');
/* VARIABLES POSTED FROM PG*/

$txnResult = isset($_GET['ResResult']) ? $_GET['ResResult'] : '';
$txnTrackID= isset($_GET['ResTrackId']) ? $_GET['ResTrackId'] : ''; //Merchant track ID
$txnPaymentID = isset($_GET['ResPaymentId']) ? $_GET['ResPaymentId'] : '';
$txnRef= isset($_GET['ResRef']) ? $_GET['ResRef'] : '';
$txnTranID = isset($_GET['ResTranId']) ? $_GET['ResTranId'] : '';
$txnAmount= isset($_GET['ResAmount']) ? $_GET['ResAmount'] : '';
$txnError = isset($_GET['ResError']) ? $_GET['ResError'] : '';

include('prod_conn.php');

/* Capture the IP address of Shared SSL*/
$ipAdd = getenv('REMOTE_ADDR');

 /* Capture the IP address from where the request comes*/  
$strResponseIPAdd=@getenv("HTTP_X_FORWARDED_FOR");

/* Check whether the IP Address from where response is received is PG IP */
	if( ($ipAdd == "205.178.146.20") || ($strResponseIPAdd == "221.134.101.175" || $strResponseIPAdd == "221.134.101.187" || $strResponseIPAdd == "221.134.101.166" || $strResponseIPAdd == "221.134.101.174" || $strResponseIPAdd == "221.134.101.169" || $strResponseIPAdd == "198.64.129.10" || $strResponseIPAdd == "198.64.133.213"))
		{
		
			$query="SELECT TRANSACTION_ID, GATEWAY_RESPONSE, DONATION_AMT FROM ONLINE_PAYMENTS WHERE TRANSACTION_ID='".$txnTrackID."'";
			$db_open = mysql_connect("$dbhost", "$dbuser", "$dbpass");
			$db = mysql_select_db("$dbdatabase");
			$result = mysql_query($query) or die (mysql_error());
			while ($row = mysql_fetch_assoc($result)) 
			{
				$TRANSIND=$row['TRANSACTION_ID'];
				$TRANS_STATUS=$row['GATEWAY_RESPONSE'];
				$DONATION_AMT=$row['DONATION_AMT'];
			}
			
			$txnResult = $TRANS_STATUS;
			$txnAmount = $DONATION_AMT;
		}
		else
		{
			$strMTRCKID =  isset($_GET['ResTrackId']) ? $_GET['ResTrackId'] : '';
			//echo $ipAdd; echo "  ".$strResponseIPAdd;
			echo "<BR>IP Address Mismatch: An invalid IP address has been detected. Your transaction cannot continue. Please contact support@yousee.in immediately with reference number -".$strMTRCKID;
			exit;
		}
?>
<html>
<head >
    <title>Transaction Response Page</title>
		<table border="1" align="center"  width="100%" >
		<tr>
		<td align="left" width="90%"><font  size = 5 color = darkblue face = verdana ><b>Transaction Response Page</td>
		<td align="right"width="10%"><IMG SRC="" WIDTH="169" HEIGHT="37" BORDER="0" ALT=""></td>
		</tr>
	</table>
</head>
<BODY bgcolor="white">
	
  <br><br> <br><br> 
	<table border="1" align="center" >
	<tr>
		<th colspan="50" bgcolor="#9999FF" ><p style= "color:White">Final Response  
    </th>
	</tr>
		
	<tr>
		<td>
			<table align="center"  border="2">
			<tr>
				<td colspan="35">Transaction Status</td>				
				<td><?php echo $txnResult;?> <td>				
			</tr>
			
			<tr>
				<td colspan="35">Merchant Reference No:[TRACK_ID]</td>				
				<td><?php echo $txnTrackID;?></td>				
			</tr>
			<tr>
				<td colspan="35">Transaction PaymentID</td>				
				<td> <?php echo $txnPaymentID;?></td>				
			</tr>
						
			<tr>
				<td colspan="35">Transaction Reference No</td>				
				<td> <?php echo $txnRef;?></td>				
			</tr>
			
			<tr>
				<td colspan="35">Transaction ID</td>				
				<td> <?php echo $txnTranID;?></td>				
			</tr>
			<tr>
				<td colspan="35">Transaction Amount</td>				
				<td> <?php echo $txnAmount;?></td>				
			</tr>
			
			<tr>
				<td colspan="35">Transaction Error</td>				
				<td><?php echo $txnError;?> </td>				
			</tr>
					
			</table>
		</td>
	</tr>
	</table>
<br><br><br><br><br>
<table border="1" align="center"  width="100%" >
	<tr>
	<td align="Left" width="90%"><font  size = 5 color = darkblue face = verdana ><b>Transaction Response Page</td>
	<td align="right"width="10%"><IMG SRC="" WIDTH="169" HEIGHT="37" BORDER="0" ALT=""></td>
	</tr>
	</table>
  <center><!-- <A href="Index.html"><p style="color:blue"><b>Click here to enter another  transaction</b></p></A> --></center>
       
</body>
</html>