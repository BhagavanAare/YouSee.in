<?
//which host has the database?
$dbhost = "205.178.146.91";

//Username with privileges to connect to database for querying purpose
$dbuser = "ucdbuser";

//Password of the above user account
$dbpass = "Only4yousee";

//Database which will be selected before performing any insertion, updation or deletion
$dbdatabase = "ucdblive";
?>