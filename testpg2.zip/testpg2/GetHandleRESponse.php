<?php

//RAJ
include('prod_conn.php');
//include('ipcheck.php');

/*
******************************************************************
			* COMPANY    - FSS Pvt. Ltd.
*****************************************************************

Name of the Program : Hosted UMI Sample Pages
Page Description    : Receives response from Payment Gateway and handles the same
Response parameters : Result,Ref,Transaction id, Payment id,Auth Code, Track ID,
                      Amount,avr(optional), UDF1-UDF5,Error
Values from Session : No
Values to Session   : No
Created by          : FSS Payment Gateway Team
Created On          : 30-04-2012
Version             : Version 3.0

***************************************************************** 
*/
/* Disclaimer:- Important Note in Sample Pages
- This is a sample demonstration page only ment for demonstration, this page should not be used in production
- Transaction data should only be accepted once from a browser at the point of input, and then kept in a way that does not allow others to modify it (example server session, database  etc.)
- Any transaction information displayed to a customer, such as amount, should be passed only as display information and the actual transactional data should be retrieved from the secure source last thing at the point of processing the transaction.
- Any information passed through the customer's browser can potentially be modified/edited/changed/deleted by the customer, or even by third parties to fraudulently alter the transaction data/information. Therefore, all transaction information should not be passed through the browser to Payment Gateway in a way that could potentially be modified (example hidden form fields). 
*/

try
{

/* Capture the IP address of Shared SSL*/
$ipAdd = getenv('REMOTE_ADDR');

 /* Capture the IP address from where the request comes*/  
$strResponseIPAdd=@getenv("HTTP_X_FORWARDED_FOR");

/* Check whether the IP Address from where response is received is PG IP */
	if( ($ipAdd == "205.178.146.20") && ($strResponseIPAdd == "221.134.101.175" || $strResponseIPAdd == "221.134.101.187" || $strResponseIPAdd == "221.134.101.166" || $strResponseIPAdd == "221.134.101.174" || $strResponseIPAdd == "221.134.101.169" || $strResponseIPAdd == "198.64.129.10" || $strResponseIPAdd == "198.64.133.213"))
		{
	
	//====================================================================================================================================	
		$ResErrorText= isset($_POST['ErrorText']) ? $_POST['ErrorText'] : ''; 	//Error Text/message
		$ResPaymentId = isset($_POST['paymentid']) ? $_POST['paymentid'] : '';	//Payment Id
		$ResTrackID = isset($_POST['trackid']) ? $_POST['trackid'] : '';        //Merchant Track ID
		$ResErrorNo = isset($_POST['Error']) ? $_POST['Error'] : '';            //Error Number

		//To collect transaction result
		$ResResult = isset($_POST['result']) ? $_POST['result'] : '';           //Transaction Result
		$ResPosdate = isset($_POST['postdate']) ? $_POST['postdate'] : '';      //Postdate
		//To collect Payment Gateway Transaction ID, this value will be used in dual verification request
		$ResTranId = isset($_POST['tranid']) ? $_POST['tranid'] : '';           //Transaction ID
		$ResAuth = isset($_POST['auth']) ? $_POST['auth'] : '';                 //Auth Code		
		$ResAVR = isset($_POST['avr']) ? $_POST['avr'] : '';                    //TRANSACTION avr					
		$ResRef = isset($_POST['ref']) ? $_POST['ref'] : '';                    //Reference Number also called Seq Number
		//To collect amount from response
		$ResAmount = isset($_POST['amt']) ? $_POST['amt'] : '';                 //Transaction Amount

		$Resudf1 = isset($_POST['udf1']) ? $_POST['udf1'] : '';                  //UDF1
		$Resudf2 = isset($_POST['udf2']) ? $_POST['udf2'] : '';                  //UDF2
		$Resudf3 = isset($_POST['udf3']) ? $_POST['udf3'] : '';                  //UDF3
		$Resudf4 = isset($_POST['udf4']) ? $_POST['udf4'] : '';                  //UDF4
		$Resudf5 = isset($_POST['udf5']) ? $_POST['udf5'] : '';                  //UDF5
					
	
		//LIST OF PARAMETERS RECEIVED BY MERCHANT FROM PAYMENT GATEWAY ENDS HERE 
	//====================================================================================================================================	
              
	/* Merchant (ME) checks, if error number is NOT present, then create Dual Verification 
	request, send to Paymnent Gateway. ME SHOULD ONLY USE PAYMENT GATEWAY TRAN ID FOR DUAL
	VERIFICATION */
    /* NOTE - MERCHANT MUST LOG THE RESPONSE RECEIVED IN LOGS AS PER BEST PRACTICE */

		if ($ResErrorNo == '')
		{
			           
			//check result is captured or approved i.e. successful
			if ($ResResult == 'CAPTURED' || $ResResult == 'APPROVED')
			{
				
				//==========================================================================================
				//==================PARAMETER VALIDATION CODE ===================================================
				/*
				//The Below condition will check the Required Parameter From PG side Blank or not,if any field is blank
				//in the below condition then it will redirected to Failed pages with proper message.
				*/
				if ($ResPaymentId == '' || $ResTrackID == '' || $ResTranId == '' || $ResAuth == '' || $ResRef == '' || $ResAmount == '')
				{
			
					$REDIRECT = 'REDIRECT=https://secure.netsolhost.com/yousee.in/testpg2/FailedTRAN.php?Message=PARMETER VALIDATION FAILED';
					echo $REDIRECT;
				}
				else
				{	
				//===================PARAMETER VALIDATION CONDITION END=========================================
									
					//If result is CAPTURED or APPROVED then below Code is execute for dual inquiry 
			   	 
					//ID given by bank to Merchant (Tranportal ID), same iD that was passed in initial request
					//$ReqTranportalId = "<id>90001320</id>";
					$ReqTranportalId = "<id>70001838</id>";

					//Password given by bank to merchant (Tranportal Password), same password that was passed in initial request
					$ReqTranportalPassword = "<password>70001838</password>";

					// Pass DUAL VERIFICATION action code, always pass "8" for DUAL VERIFICATION
					$INQAction = "<action>8</action>";

					//Pass PG Transaction ID for Dual Verification
					$INQTransId  = "<transid>".$ResTranId."</transid>"; 
								
					//create string for request of input parameters
					$INQRequest=$ReqTranportalId.$ReqTranportalPassword.$INQAction.$INQTransId;

					
					//DUAL VERIFIACTION URL, this is test environment URL, contact bank for production DUAL Verification URL
					//$INQUrl = "https://securepgtest.fssnet.co.in/pgway/servlet/TranPortalXMLServlet";
					$INQUrl = "https://securepg.fssnet.co.in/pgway/servlet/TranPortalXMLServlet";
			     
					//PHP FUNCTION for connection and posting the request ..starts here
					$dvreq = curl_init() or die(curl_error()); 
					curl_setopt($dvreq, CURLOPT_POST,1); 
					curl_setopt($dvreq, CURLOPT_POSTFIELDS,$INQRequest); 
					curl_setopt($dvreq, CURLOPT_URL,$INQUrl); 
					curl_setopt($dvreq, CURLOPT_PORT, 443);
					curl_setopt($dvreq, CURLOPT_RETURNTRANSFER, 1); 
					curl_setopt($dvreq, CURLOPT_SSL_VERIFYHOST,0); 
					curl_setopt($dvreq, CURLOPT_SSL_VERIFYPEER,0); 
					$dataret=curl_exec($dvreq) or die(curl_error());
					curl_close($dvreq); 
					//PHP FUNCTION for connection and posting the request ..ends here

					//XML response received for DUAL VERIFICATION.
					/* 
					NOTE - MERCHANT MUST LOG THE RESPONSE RECEIVED IN LOGS AS PER BEST PRACTICE
					*/
					$TranInqResponse = $dataret;
					//print_r $DVresponse;
					$GEnXMLForm="<xmltg>".$TranInqResponse."</xmltg>";
					$xmlSTR = simplexml_load_string( $GEnXMLForm,null,true);
               
					//Collect DUAL VERIFICATION RESULT
					$INQCheck = $xmlSTR-> result;
               
					//If DUAL VERIFICATION RESULT is CAPTURED or APPROVED or SUCCESS
					if ($INQCheck == 'CAPTURED' || $INQCheck == 'APPROVED' || $INQCheck == 'SUCCESS')
					{
									  
						//Collect DUAL VERIFICATION RESULT
																		
						$INQResResult = $xmlSTR->result;//It will give DualInquiry Result 
						$INQResAmount = $xmlSTR->amt;//It will give Amount
						$INQResTrackId = $xmlSTR->trackid;//It will give TrackID ENROLLED
						$INQResPayid = $xmlSTR->payid;//It will give payid
						$INQResRef = $xmlSTR->ref;//It will give Ref.NO.
						$INQResTranid = $xmlSTR->tranid;//It will give tranid
						//MERCHANT CAN GET ALL VERIFICATION RESULT PARAMETERS USING BELOW CODE 
						/*
						$INQResAutht = $xmlSTR->auth;//It will give Auth 
						$INQResAvr = $xmlSTR->avr;//It will give AVR 
						$INQResPostdate = $xmlSTR->postdate;//It will give  postdate
						$INQResUdf1 = $xmlSTR->udf1;//It will give udf1
						$INQResUdf2 = $xmlSTR->udf2;//It will give udf2
						$INQResUdf3 = $xmlSTR->udf3;//It will give udf3
						$INQResUdf4 = $xmlSTR->udf4;//It will give udf4
						$INQResUdf5 = $xmlSTR->udf5;//It will give udf5
						*/
			  
						/*
						IMPORTANT NOTE - MERCHANT DOES RESPONSE HANDLING AND VALIDATIONS OF 
						TRACK ID, AMOUNT AT THIS PLACE. THEN ONLY MERCHANT SHOULD UPDATE 
						TRANACTION PAYMENT STATUS IN MERCHANT DATABASE AT THIS POSITION 
						AND THEN REDIRECT CUSTOMER ON RESULT PAGE
						*/
						
						//MODIFIED BY RAJ - VERIFYING IF THE AMT IS SAME AS ENTERED BY OUR DEAR DONOR
						$query="SELECT DONATION_AMT FROM ONLINE_PAYMENTS WHERE TRANSACTION_ID='".$ResTrackID."'";
						$db_open = mysql_connect("$dbhost", "$dbuser", "$dbpass");
						$db = mysql_select_db("$dbdatabase");
						$result = mysql_query($query) or die (mysql_error());
						while ($row = mysql_fetch_assoc($result)) 
							{
								$donationAMT=$row['DONATION_AMT'];
							}

						
						if ( $donationAMT != round($INQResAmount, 0) )
						{
						$REDIRECT = 'REDIRECT=https://secure.netsolhost.com/yousee.in/testpg2/FailedTRAN.php?message=AMOUNT MISMATCH -  '.$donationAMT.' -'.$ResAmount.' ('.$ResResult.' )&ME_TX_ID='.$INQTransId;
						//echo "I am here -1";
						$query="UPDATE ONLINE_PAYMENTS SET TRANS_STATUS=\"AMOUNT MISMATCH\", TRANS_NUMBER=".$ResTranId." where TRANSACTION_ID =".$ResTrackID;
						$db_open = mysql_connect("$dbhost", "$dbuser", "$dbpass");
						$db = mysql_select_db("$dbdatabase");
						$result = mysql_query($query) or die (mysql_error());
						echo $REDIRECT;
						}
						
						//RAJ
						//AMOUNT MATCHING PASSED, HENCE UPDAING THE DB WITH APPROVED STATUS
						$db_open = mysql_connect("$dbhost", "$dbuser", "$dbpass");
						$db = mysql_select_db("$dbdatabase");
						$query="UPDATE ONLINE_PAYMENTS SET TRANS_STATUS=\"APPROVED\", TRANS_NUMBER=".$INQResTranid.", PAYMENT_ID_GATEWAY=".$INQResPayid." where TRANSACTION_ID=".$INQResTrackId;
						$result = mysql_query($query) or die (mysql_error());
						
			  
						/* !!IMPORTANT INFORMATION!!
						During redirection, ME can pass the values as per ME requirement.
						NOTE: NO PROCESSING should be done on the RESULT PAGE basis of values passed in the RESULT PAGE from this page. 
						ME does all validations on the responseURL page and then redirects the customer to RESULT 
						PAGE ONLY FOR RECEIPT PRESENTATION/TRANSACTION STATUS CONFIRMATION
						For demonstration purpose the result and track id are passed to Result page
						*/
					
						$query="UPDATE ONLINE_PAYMENTS SET TRANS_STATUS=\"APPROVED\", GATEWAY_RESPONSE=\"PAYMENT SUCCESSFUL\" where TRANSACTION_ID =".$INQResTrackId;
						$db_open = mysql_connect("$dbhost", "$dbuser", "$dbpass");
						$db = mysql_select_db("$dbdatabase");
						$result = mysql_query($query) or die (mysql_error());
						$REDIRECT = 'REDIRECT=https://secure.netsolhost.com/yousee.in/testpg2/StatusTRAN.php?ResResult='.$INQResResult.'&ResTrackId='.$INQResTrackId.'&ResAmount='.$INQResAmount.'&ResPaymentId='.$INQResPayid.'&ResRef='.$INQResRef.'&ResTranId='.$INQResTranid.'&ResError='.$ResErrorText;
						echo $REDIRECT;
								  
					}
					else
					{
						/*
						ERROR IN TRANSACTION PROCESSING
						IMPORTANT NOTE - MERCHANT SHOULD UPDATE 
						TRANACTION PAYMENT STATUS IN MERCHANT DATABASE AT THIS POSITION 
						AND THEN REDIRECT CUSTOMER ON RESULT PAGE
						*/
						$query="UPDATE ONLINE_PAYMENTS SET TRANS_STATUS=\"FAILED\", GATEWAY_RESPONSE=\"ERROR - PAYMENT FAILED IN DUAL VERIFICATION\" where TRANSACTION_ID =".$INQResTrackId;
						$db_open = mysql_connect("$dbhost", "$dbuser", "$dbpass");
						$db = mysql_select_db("$dbdatabase");
						$result = mysql_query($query) or die (mysql_error());
						$REDIRECT = 'REDIRECT=https://secure.netsolhost.com/yousee.in/testpg2/FailedTRAN.php?Message=Transaction Failed&ResTrackId='.$ResTrackID.'&ResAmount='.$ResAmount.'&ResError='.$INQCheck;														
						echo $REDIRECT;
													
					}

				}
			}
			else
			{

				/*
				IMPORTANT NOTE - MERCHANT SHOULD UPDATE TRANACTION PAYMENT STATUS IN MERCHANT DATABASE AT THIS POSITION 
				AND THEN REDIRECT CUSTOMER ON RESULT PAGE
				*/
				$REDIRECT = 'REDIRECT=https://secure.netsolhost.com/yousee.in/testpg2/StatusTRAN.php?ResResult='.$ResResult.'&ResTrackId='.$ResTrackID.'&ResAmount='.$ResAmount.'&ResPaymentId='.$ResPaymentId.'&ResRef='.$ResRef.'&ResTranId='.$ResTranId.'&ResError='.$ResErrorText;														
				echo $REDIRECT;
						
			}
		}
		else 
		{
		/*
		ERROR IN TRANSACTION PROCESSING
		IMPORTANT NOTE - MERCHANT SHOULD UPDATE 
		TRANACTION PAYMENT STATUS IN MERCHANT DATABASE AT THIS POSITION 
		AND THEN REDIRECT CUSTOMER ON RESULT PAGE
		*/
		$query="UPDATE ONLINE_PAYMENTS SET TRANS_STATUS=\"FAILED\", GATEWAY_RESPONSE=\"ERROR IN PROCESSING PAYMENT\" where TRANSACTION_ID =".$INQResTrackId;
		$db_open = mysql_connect("$dbhost", "$dbuser", "$dbpass");
		$db = mysql_select_db("$dbdatabase");
		$result = mysql_query($query) or die (mysql_error());
		$REDIRECT = 'REDIRECT=https://secure.netsolhost.com/yousee.in/testpg2/FailedTRAN.php?Message=Transaction Failed&ResTrackId='.$ResTrackID.'&ResAmount='.$ResAmount.'&ResError='.$ResErrorText;
		echo $REDIRECT;
		}
	
	}
	else
	{
	
		/*
		IMPORTAN NOTE - IF IP ADDRESS MISMATCHES, ME LOGS DETAILS IN LOGS,
		UPDATES MERCHANT DATABASE WITH PAYMENT FAILURE, REDIRECTS CUSTOMER 
		ON FAILURE PAGE WITH RESPECTIVE MESSAGE
		*/
		/*
		<!-- 
		to get the IP Address in case of proxy server used
		function getIPfromXForwarded() { 
		$ipString=@getenv("HTTP_X_FORWARDED_FOR"); 
		$addr = explode(",",$ipString); 
		return $addr[sizeof($addr)-1]; 
		} 
		*/
		$query="UPDATE ONLINE_PAYMENTS SET TRANS_STATUS=\"ABORTED\", GATEWAY_RESPONSE=\"IP ADDRESS MISMATCH\" where TRANSACTION_ID =".$INQResTrackId;
		$db_open = mysql_connect("$dbhost", "$dbuser", "$dbpass");
		$db = mysql_select_db("$dbdatabase");
		//$result = mysql_query($query) or die (mysql_error());
		$REDIRECT = 'REDIRECT=https://secure.netsolhost.com/yousee.in/testpg2/FailedTRAN.php?Message=--IP MISMATCH-- Response IP Address is: '.$strResponseIPAdd;
		echo $REDIRECT;
	}
}
catch(Exception $e)
{
	var_dump($e->getMessage());
}



?>