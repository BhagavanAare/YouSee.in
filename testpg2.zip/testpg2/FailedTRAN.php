<?php

$strMessage =  isset($_GET['Message']) ? $_GET['Message'] : '';
$strMTRCKID =  isset($_GET['ResTrackId']) ? $_GET['ResTrackId'] : '';
//$strAmt =  isset($_GET['ResAmount']) ? $_GET['ResAmount'] : '';
$strError =  isset($_GET['ResError']) ? $_GET['ResError'] : '';
			
include('prod_conn.php');

/* Capture the IP address of Shared SSL*/
$ipAdd = getenv('REMOTE_ADDR');

 /* Capture the IP address from where the request comes*/  
$strResponseIPAdd=@getenv("HTTP_X_FORWARDED_FOR");

/* Check whether the IP Address from where response is received is PG IP */
	if( ($ipAdd == "205.178.146.20") || ( $strResponseIPAdd == "221.134.101.175" || $strResponseIPAdd == "221.134.101.187" || $strResponseIPAdd == "221.134.101.166" || $strResponseIPAdd == "221.134.101.174" || $strResponseIPAdd == "221.134.101.169" || $strResponseIPAdd == "198.64.129.10" || $strResponseIPAdd == "198.64.133.213"))
		{
		
			$query="SELECT TRANSACTION_ID, GATEWAY_RESPONSE, DONATION_AMT FROM ONLINE_PAYMENTS WHERE TRANSACTION_ID='".$strMTRCKID."'";
			$db_open = mysql_connect("$dbhost", "$dbuser", "$dbpass");
			$db = mysql_select_db("$dbdatabase");
			$result = mysql_query($query) or die (mysql_error());
			while ($row = mysql_fetch_assoc($result)) 
			{
				$TRANSIND=$row['TRANSACTION_ID'];
				$TRANS_STATUS=$row['GATEWAY_RESPONSE'];
				$DONATION_AMT=$row['DONATION_AMT'];
			}
			
			$strMessage = $TRANS_STATUS;
			$strAmt = $DONATION_AMT;
		}
		else
		{
			$strMTRCKID =  isset($_GET['ResTrackId']) ? $_GET['ResTrackId'] : '';
			echo "IP Address Mismatch: An invalid IP address has been detected. Your transaction cannot continue. Please contact support@yousee.in immediately with reference number -".$strMTRCKID;
			exit;
		}
?>
?>
<html>
<head >
    <title>Response Page</title>
		<table border="1" align="center"  width="100%" >
		<tr>
		<td align="left" width="90%"><font  size = 5 color = darkblue face = verdana ><b>Response Page</td>
		<td align="right"width="10%"><IMG SRC="" WIDTH="169" HEIGHT="37" BORDER="0" ALT=""></td>
		</tr>
	</table>
</head>
<BODY bgcolor="white">
	
  <br><br> <br><br> 
	<table border="1" align="center" >
	<tr>
		<th colspan="50" bgcolor="darkblue" ><p style= "color:white">Transaction Failed Response </th>
	</tr>
	
			<tr>
				<td colspan="35"> Transaction Status </td>
				<td> <?php echo $strMessage;?></td>
			</tr>
			<tr>
				<td colspan="35"> Merchant Reference No:[TRACK_ID] </td>
				<td> <?php echo $strMTRCKID;?> </td>
			</tr>
			<tr>
				<td colspan="35"> Transaction Amount </td>
				<td> <?php echo $strAmt;?> </td>
			</tr>
					
			<tr>
				<td colspan="35"> Error Description </td>
				<td><center><FONT color="red"><b> <?php echo $strError;?></FONT></td>
			</tr>		
	</table>
<br><br><br><br><br>
<table border="1" align="center"  width="100%" >
	<tr>
	<td align="Left" width="90%"><font  size = 5 color = darkblue face = verdana ><b>Sample Page</td>
	<td align="right"width="10%"><IMG SRC="" WIDTH="169" HEIGHT="37" BORDER="0" ALT=""></td>
	</tr>
	</table>
  <center><!-- <A href="Index.html"><p style="color:blue"><b>Click here to enter another  transaction</b></p></A> --> </center>
       
</body>
</html>