<?php
// Receives response from processpayment.php, DB
include("prod_conn.php");
$TRANSACTION_ID = $_POST['TRANSACTION_ID'];
mysql_connect("$dbhost","$dbuser","$dbpass");
mysql_select_db("$dbdatabase");
$query = "SELECT FIRST_NAME, LAST_NAME, FATHER_HUSBAND_NAME, DOB, GENDER, ADDRESS, VILLAGE_TOWN, STATE, COUNTRY, PIN_CODE, TITLE_DESIGNATION, MOBILE_PHONE_NO,
PERSONAL_EMAIL_ID,OFFICIAL_EMAIL_ID,PAN,FEATURE_PERMISSION,FEATURE_QUOTE,DISPLAY_NAME,IMAGE_URL,CERTIFICATE_ID,DONATION_AMT,TRANS_STATUS
FROM ONLINE_PAYMENTS
WHERE TRANSACTION_ID=$TRANSACTION_ID";
$result = mysql_query($query);
while ($row = mysql_fetch_assoc($result)) {
$FIRST_NAME = $row['FIRST_NAME'];
$LAST_NAME = $row['LAST_NAME'];
$FATHER_HUSBAND_NAME = $row['FATHER_HUSBAND_NAME'];
$DOB = $row['DOB'];
$GENDER = $row['GENDER'];
$TITLE_DESIGNATION = $row['TITLE_DESIGNATION'];
$ADDRESS = $row['ADDRESS'];
$COUNTRY = $row['ADDRESS_COUNTRY'];
$EMAILID = $row['OFFICIAL_EMAIL_ID'];
$OFFICIAL_EMAIL_ID = $EMAILID;
$PERSONAL_EMAIL_ID = $EMAILID;
$PAN = $row['PAN'];
$FEATURE_PERMISSION = $row['FEATURE_PERMISSION']; 
$FEATURE_QUOTE = $row['FEATURE_QUOTE'];
$IMAGE_URL = $row['IMAGE_URL'];
$CERTIFICATE_ID = $row['CERTIFICATE_ID'];
$MOBILE_PHONE_NO = $row['MOBILE_PHONE_NO'];
$DONATION_AMT = $row['DONATION_AMT'];
}

//For payment gateway
$name = "$FIRST_NAME"." "."$LAST_NAME";
$DISPLAY_NAME = $name;
$email = $EMAILID;
$email = str_replace( array('>>','<<','>','<','(',')','{','}','[',']','?','&','*','~','`','!','#','$','%','^','=','+','|','\\','/',':','\'','"',',',';'), ' ', $EMAILID);
$mobile = str_replace( array('>>','<<','>','<','(',')','{','}','[',']','?','&','*','~','`','!','#','$','%','^','=','+','|','\\','/',':','\'','"',',',';'), ' ', $MOBILE_PHONE_NO);
//$address = "$ADDRESS_LINE_1". ."$ADDRESS_LINE_2". ."$ADDRESS_CITY". ."$ADDRESS_STATE". ."$ADDRESS_ZIPCODE". ."$ADDRESS_COUNTRY";
//$address =  str_replace(',', '', $address);
$ADDRESS = str_replace( array('>>','<<','>','<','(',')','{','}','[',']','?','&','*','~','`','!','#','$','%','^','=','+','|','\\','/',':','\'','"',',',';'), ' ', $ADDRESS);
//$ADDRESS = $address;
$AMOUNT = $DONATION_AMT;



/*
*****************************************************************
			* COMPANY    - FSS Pvt. Ltd.
*****************************************************************

Name of the Program : Hosted UMI Sample Pages
Page Description    : Allows Merchant to connect Payment Gateway and send request
Request parameters  : TranporatID,TranportalPassword,Action,Amount,Currency,Merchant 
                      Response/Error URL & TrackID,Language,UDF1-UDF5
Response parameters : Payment Id, Pay Page URL, Error
Values from Session : No 
Values to Session   : No
Created by          : FSS Payment Gateway Team
Created On          : 30-04-2012
Version             : Version 3.0
					
*****************************************************************
NOTE - 
This sample pages are developed and tested on below platform

PHP  Version     - 5.3.5
Web/App Server   - Apache 2.2.17/Wamp 2.1
Operating System - Windows 2003/7
*****************************************************************

Disclaimer:- Important Note in Sample Pages
- This is a sample demonstration page only ment for demonstration, this page 
should not be used in production
- Transaction data should only be accepted once from a browser at the point 
of input, and then kept in a way that does not allow others to modify it 
(example server session, database  etc.)
- Any transaction information displayed to a customer, such as amount, should 
be passed only as display information and the actual transactional data should 
be retrieved from the secure source last thing at the point of processing the transaction.
- Any information passed through the customer's browser can potentially be 
modified/edited/changed/deleted by the customer, or even by third parties to 
fraudulently alter the transaction data/information. Therefore, all transaction 
information should not be passed through the browser to Payment Gateway in a way
that could potentially be modified (example hidden form fields). 
*****************************************************************
*/

/* 
IMPORTANT INFORMATION
This document is provided by Financial Software and System Pvt Ltd on the basis 
that you will treat it as private and confidential.

Data used in examples and sample data files are intended to be fictional and any 
resemblance to real persons or entities is entirely coincidental.

This example assumes that a form has been sent to this example with the required 
fields. The example then processes the command and displays the receipt or error 
to a HTML page in the users web browser.
*/
/*  sign "&" is mandatory to mention with in the end of passed value, in below section this 
to make the string     Merchant can use their on logic of creating the string with required 
inputs, below is just a basic method on how to create a request string and pass the values 
to Payment Gateway */	

/*Getting Transaction Amount and Merchant TrackID from Initial HTML page
Since this sample page for demonstration, values from HTML page are directly
taken from browser and used for transaction processing. Merchants SHOULD NOT
follow this practice in production environment. */

//MODIFIED BY RAJ - WE USE DIFF VARIABLES, HENCE COMMENTING THE BELOW AND ASSIGNING
//THE VALUES DIRECTLY.
//$TranTrackid=isset($_POST['MTrackid']) ? $_POST['MTrackid'] : '';
//$TranAmount=isset($_POST['MAmount']) ? $_POST['MAmount'] : '';

$TranTrackid=$TRANSACTION_ID;
$TranAmount=$DONATION_AMT;

/* to pass Tranportal ID provided by the bank to merchant. Tranportal ID is sensitive information
of merchant from the bank, merchant MUST ensure that Tranportal ID is never passed to customer 
browser by any means. Merchant MUST ensure that Tranportal ID is stored in secure environment & 
securely at merchant end. Tranportal Id is referred as id. Tranportal ID for test and production will be 
different, please contact bank for test and production Tranportal ID*/
//$id="id=XXXXX";
//$id="id=90001320";
$id="id=70001838";

/* to pass Tranportal password provided by the bank to merchant. Tranportal password is sensitive 
information of merchant from the bank, merchant MUST ensure that Tranportal password is never passed 
to customer browser by any means. Merchant MUST ensure that Tranportal password is stored in secure 
environment & securely at merchant end. Tranportal password is referred as password. Tranportal 
password for test and production will be different, please contact bank for test and production
Tranportal password */
$password="password=70001838";

/* Action Code of the transaction, this refers to type of transaction. Action Code 1 stands of 
Purchase transaction and action code 4 stands for Authorization (pre-auth). Merchant should 
confirm from Bank action code enabled for the merchant by the bank*/ 
$action="action=1";

/* Transaction language, THIS MUST BE ALWAYS USA. */
$langid="langid=USA";

/* Currency code of the transaction. By default INR i.e. 356 is configured. If merchant wishes 
to do multiple currency code transaction, merchant needs to check with bank team on the available 
currency code */
$currencycode="currencycode=356";

/* Transaction Amount that will be send to payment gateway by merchant for processing
NOTE - Merchant MUST ensure amount is sent from merchant back-end system like database
and not from customer browser. In below sample AMT is hard-coded, merchant to pass 
trasnaction amount here. */
$amt="amt=".$TranAmount;

/* Response URL where Payment gateway will send response once transaction processing is completed 
Merchant MUST esure that below points in Response URL
1- Response URL must start with http://
2- the Response URL SHOULD NOT have any additional paramteres or query string */ 
//$responseURL="responseURL=http://www.merchantdemo.com/GetHandleRESponse.php";
$responseURL="responseURL=https://secure.netsolhost.com/yousee.in/testpg2/GetHandleRESponse.php";

/* Error URL where Payment gateway will send response in case any issues while processing the transaction 
Merchant MUST esure that below points in ErrorURL 
1- error url must start with http://
2- the error url SHOULD NOT have any additional paramteres or query string
*/ 
//$errorURL="errorURL=http://www.merchantdemo.com/FailedTRAN.php";
$errorURL="errorURL=https://secure.netsolhost.com/yousee.in/testpg2/FailedTRAN.php";

/* To pass the merchant track id, in below sample merchant track id is hard-coded. Merchant
MUST pass his transaction ID (track ID) in this parameter. Track Id passed here should be 
from merchant backend system like database and not from customer browser*/
$trackid="trackid=".$TranTrackid;

/* User Defined Fileds as per Merchant or bank requirment. Merchant MUST ensure merchant 
merchant is not passing junk values OR CRLF in any of the UDF. In below sample UDF values 
are not utilized */
//$udf1="udf1=Test1";
//$udf2="udf2=Test2";
//$udf3="udf3=Test3";
//$udf4="udf4=Test4";
//$udf5="udf5=Test5";

$udf1="udf1=YouseeCertificate";
$udf2="udf2=".$EMAILID;
$udf3="udf3=".$mobile;
$udf4="udf4=".$ADDRESS;
$udf5="udf5=YouseeProjects";


/*
ME should now do the validations on the amount value set like - 
a) Transaction Amount should not be blank and should be only numeric
b) Language should always be USA
c) Action Code should not be blank
d) UDF values should not have junk values and CRLF (line terminating parameters)Like--> [ !#$%^&*()+[]\\\';,{}|\":<>?~` ]
*/

/* Now merchant sets all the inputs in one string for passing to the Payment Gateway URL */		
$param=$id."&".$password."&".$action."&".$langid."&".$currencycode."&".$amt."&".$responseURL."&".$errorURL."&".$trackid."&".$udf1."&".$udf2."&".$udf3."&".$udf4."&".$udf5;

/* This is Payment Gateway Test URL where merchant sends request. This is test enviornment URL, 
production URL will be different and will be shared by Bank during production movement */
//$url = "https://securepgtest.fssnet.co.in/pgway/servlet/PaymentInitHTTPServlet";
$url = "https://securepg.fssnet.co.in/pgway/servlet/PaymentInitHTTPServlet";

/* 
Log the complete request in the log file for future reference
Now creating a connection and sending request
Note - In PHP CURL function is used for sending TCPIP request
*/
$ch = curl_init() or die(curl_error()); 
curl_setopt($ch, CURLOPT_POST,1); 
curl_setopt($ch, CURLOPT_POSTFIELDS,$param); 
curl_setopt($ch, CURLOPT_PORT, 443); // port 443
curl_setopt($ch, CURLOPT_URL,$url);// here the request is sent to payment gateway 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,0); //create a SSL connection object server-to-server
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0); 
$data1=curl_exec($ch) or die(curl_error());

curl_close($ch); 

$response = $data1;
            try
			{
				
				
				$index=strpos($response,"!-");
				$ErrorCheck=substr($response, 1, $index-1);//This line will find Error Keyword in response
				
				if($ErrorCheck == 'ERROR')//This block will check for Error in response
				{
					$failedurl='https://secure.netsolhost.com/yousee.in/testpg2/FailedTRAN.php?Message=Transaction Failed&ResTrackId='.$TranTrackid.'&ResAmount='.$TranAmount.'&ResError='.$response;
					header("location:". $failedurl );
					
					
												
				}
				else
				{
					//echo $response;
					// If Payment Gateway response has Payment ID & Pay page URL		
					$i =  strpos($response,":");
					// Merchant MUST map (update) the Payment ID received with the merchant Track Id in his database at this place.
					$paymentId = substr($response, 0, $i);
					$paymentPage = substr( $response, $i + 1);
					// here redirecting the customer browser from ME site to Payment Gateway Page with the Payment ID
					$r = $paymentPage . "?PaymentID=" . $paymentId;
					header("location:". $r );
				}
				
				
							
			}
			catch(Exception $e)
			{
				var_dump($e->getMessage());
			}
?>